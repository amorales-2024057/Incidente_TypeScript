// ============================================================
// WORDS DATABASE - Cargado desde archivo TXT
// ============================================================
let WORDS = {
    facil: [],
    intermedio: [],
    dificil: []
};

// Configuración de niveles
const MIN_LETTERS = {
    facil: 8,
    intermedio: 9,
    dificil: 10
};

const LEVEL_CONFIG = {
    facil: { lives: 6, hintsToShow: 3, color: '#6ebc6e', name: 'FACIL' },
    intermedio: { lives: 5, hintsToShow: 2, color: '#d4af37', name: 'INTERMEDIO' },
    dificil: { lives: 4, hintsToShow: 1, color: '#e05252', name: 'DIFICIL' }
};

// ============================================================
// ESTADO DEL JUEGO
// ============================================================
let state = {
    playerName: '',
    level: 'facil',
    word: '',
    guessed: new Set(),
    wrong: 0,
    maxLives: 6,
    hintUsed: false,
    gameOver: false,
    correctCount: 0,
    wrongCount: 0,
    wordsLoaded: false
};

// ============================================================
// CARGAR PALABRAS DEL ARCHIVO TXT
// ============================================================
async function loadWordsFromFile() {
    try {
        const response = await fetch('palabras.txt');
        const text = await response.text();
        
        const lines = text.split('\n');
        let currentLevel = null;
        
        for (let line of lines) {
            line = line.trim();
            if (line === '') continue;
            
            if (line.includes('# NIVEL FACIL')) {
                currentLevel = 'facil';
                continue;
            } else if (line.includes('# NIVEL INTERMEDIO')) {
                currentLevel = 'intermedio';
                continue;
            } else if (line.includes('# NIVEL DIFICIL')) {
                currentLevel = 'dificil';
                continue;
            }
            
            if (line.startsWith('#')) continue;
            
            if (currentLevel && line.length >= MIN_LETTERS[currentLevel]) {
                WORDS[currentLevel].push(line.toLowerCase());
            }
        }
        
        // Palabras por defecto si faltan
        for (const level of ['facil', 'intermedio', 'dificil']) {
            if (WORDS[level].length < 15) {
                addDefaultWords(level);
            }
        }
        
        console.log('Palabras cargadas:', {
            facil: WORDS.facil.length,
            intermedio: WORDS.intermedio.length,
            dificil: WORDS.dificil.length
        });
        
        state.wordsLoaded = true;
        return true;
    } catch (error) {
        console.error('Error cargando palabras:', error);
        loadDefaultWords();
        return false;
    }
}

function addDefaultWords(level) {
    const defaultWords = {
        facil: ["mariposa", "calendario", "elefante", "biblioteca", "chocolate",
                "aventuras", "dinosaurio", "computadora", "zanahoria", "perfumado",
                "manzanilla", "escritorio", "palmeras", "calcetines", "ventilador"],
        intermedio: ["acertijo", "equilibrio", "telescopio", "magnetismo", "fotografia",
                     "algoritmo", "escorpion", "cuarentena", "laberinto", "respiracion",
                     "malabarista", "arquitecto", "sabiduria", "revolucion", "microscopio"],
        dificil: ["extraordinario", "electrodomestico", "inconstitucional", "supersticion",
                  "biodiversidad", "autosuficiente", "contaminacion", "administracion",
                  "interrogatorio", "invulnerable", "meteorologia", "multiplicacion",
                  "protagonista", "irresponsable", "transparencia"]
    };
    WORDS[level] = defaultWords[level];
}

function loadDefaultWords() {
    addDefaultWords('facil');
    addDefaultWords('intermedio');
    addDefaultWords('dificil');
    state.wordsLoaded = true;
}

// ============================================================
// DIBUJAR EL AHORCADO EN CANVAS (8 PASOS)
// ============================================================
const canvas = document.getElementById('hangmanCanvas');
const ctx = canvas.getContext('2d');

function drawHangman(step) {
    const w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h);
    
    // Color base
    ctx.strokeStyle = '#888';
    ctx.lineWidth = 2;
    
    // Base
    ctx.beginPath();
    ctx.moveTo(20, h - 20);
    ctx.lineTo(w - 20, h - 20);
    ctx.stroke();
    
    // Poste vertical
    ctx.beginPath();
    ctx.moveTo(50, h - 20);
    ctx.lineTo(50, 30);
    ctx.stroke();
    
    // Viga horizontal
    ctx.beginPath();
    ctx.moveTo(50, 30);
    ctx.lineTo(170, 30);
    ctx.stroke();
    
    // Cuerda
    ctx.beginPath();
    ctx.moveTo(170, 30);
    ctx.lineTo(170, 60);
    ctx.stroke();
    
    if (step === 0) return;
    
    ctx.strokeStyle = '#e05252';
    ctx.lineWidth = 2;
    
    const cx = 170;
    const cabezaY = 60;
    const radio = 18;
    
    // Paso 1: Cabeza
    if (step >= 1) {
        ctx.beginPath();
        ctx.arc(cx, cabezaY + radio, radio, 0, Math.PI * 2);
        ctx.stroke();
    }
    
    // Paso 2: Cuerpo
    if (step >= 2) {
        ctx.beginPath();
        ctx.moveTo(cx, cabezaY + radio * 2);
        ctx.lineTo(cx, cabezaY + radio * 2 + 50);
        ctx.stroke();
    }
    
    // Paso 3: Brazo izquierdo
    if (step >= 3) {
        ctx.beginPath();
        ctx.moveTo(cx, cabezaY + radio * 2 + 15);
        ctx.lineTo(cx - 30, cabezaY + radio * 2 + 35);
        ctx.stroke();
    }
    
    // Paso 4: Brazo derecho
    if (step >= 4) {
        ctx.beginPath();
        ctx.moveTo(cx, cabezaY + radio * 2 + 15);
        ctx.lineTo(cx + 30, cabezaY + radio * 2 + 35);
        ctx.stroke();
    }
    
    // Paso 5: Pierna izquierda
    if (step >= 5) {
        ctx.beginPath();
        ctx.moveTo(cx, cabezaY + radio * 2 + 50);
        ctx.lineTo(cx - 25, cabezaY + radio * 2 + 85);
        ctx.stroke();
    }
    
    // Paso 6: Pierna derecha
    if (step >= 6) {
        ctx.beginPath();
        ctx.moveTo(cx, cabezaY + radio * 2 + 50);
        ctx.lineTo(cx + 25, cabezaY + radio * 2 + 85);
        ctx.stroke();
    }
    
    // Paso 7: Pie izquierdo
    if (step >= 7) {
        ctx.beginPath();
        ctx.moveTo(cx - 25, cabezaY + radio * 2 + 85);
        ctx.lineTo(cx - 40, cabezaY + radio * 2 + 85);
        ctx.stroke();
    }
    
    // Paso 8: Pie derecho
    if (step >= 8) {
        ctx.beginPath();
        ctx.moveTo(cx + 25, cabezaY + radio * 2 + 85);
        ctx.lineTo(cx + 40, cabezaY + radio * 2 + 85);
        ctx.stroke();
    }
}

// ============================================================
// CREAR TECLADO DINÁMICAMENTE
// ============================================================
const LETRAS = [
    ['Q','W','E','R','T','Y','U','I','O','P'],
    ['A','S','D','F','G','H','J','K','L','Ñ'],
    ['Z','X','C','V','B','N','M']
];

function buildKeyboard() {
    const kb = document.getElementById('keyboard');
    kb.innerHTML = '';
    
    for (let fila of LETRAS) {
        const rowDiv = document.createElement('div');
        rowDiv.className = 'teclado-fila';
        
        for (let letra of fila) {
            const btn = document.createElement('button');
            btn.className = 'tecla';
            btn.textContent = letra;
            btn.dataset.letter = letra;
            btn.onclick = () => handleGuess(letra);
            rowDiv.appendChild(btn);
        }
        kb.appendChild(rowDiv);
    }
}

// ============================================================
// MOSTRAR PALABRA CON GUIONES
// ============================================================
function buildWordDisplay(word, guessed) {
    const display = document.getElementById('wordDisplay');
    display.innerHTML = '';
    
    for (let i = 0; i < word.length; i++) {
        const letra = word[i];
        
        if (letra === ' ') {
            const espacio = document.createElement('div');
            espacio.style.width = '30px';
            display.appendChild(espacio);
            continue;
        }
        
        const slot = document.createElement('div');
        slot.className = 'letra-slot';
        
        const letraDiv = document.createElement('div');
        letraDiv.className = 'letra';
        letraDiv.id = `letra-${i}`;
        
        if (guessed.has(letra.toUpperCase())) {
            letraDiv.textContent = letra.toUpperCase();
        }
        
        const guion = document.createElement('div');
        guion.className = 'guion';
        
        slot.appendChild(letraDiv);
        slot.appendChild(guion);
        display.appendChild(slot);
    }
}

function revealLetter(word, letter) {
    for (let i = 0; i < word.length; i++) {
        if (word[i].toUpperCase() === letter) {
            const el = document.getElementById(`letra-${i}`);
            if (el && !el.textContent) {
                el.textContent = word[i].toUpperCase();
                el.style.color = '#6ebc6e';
            }
        }
    }
}

function revealAll(word) {
    for (let i = 0; i < word.length; i++) {
        const el = document.getElementById(`letra-${i}`);
        if (el && !el.textContent) {
            el.textContent = word[i].toUpperCase();
            el.style.color = '#e05252';
        }
    }
}

// ============================================================
// SISTEMA DE VIDAS
// ============================================================
function buildLives(max) {
    const container = document.getElementById('livesContainer');
    container.innerHTML = '';
    
    for (let i = 0; i < max; i++) {
        const vida = document.createElement('div');
        vida.className = 'vida';
        vida.id = `vida-${i}`;
        container.appendChild(vida);
    }
}

function updateLives(wrong, max) {
    for (let i = 0; i < max; i++) {
        const vida = document.getElementById(`vida-${i}`);
        if (vida) {
            if (i >= (max - wrong)) {
                vida.classList.add('perdida');
            } else {
                vida.classList.remove('perdida');
            }
        }
    }
}

// ============================================================
// SISTEMA DE PISTAS
// ============================================================
function getHint(word, guessed, level) {
    const clean = word.toUpperCase();
    const hintsToShow = LEVEL_CONFIG[level].hintsToShow;
    const letrasUnicas = [...new Set(clean.split(''))].filter(c => !guessed.has(c));
    const reveladas = [];
    
    for (let i = 0; i < Math.min(hintsToShow, letrasUnicas.length); i++) {
        const idx = Math.floor(Math.random() * letrasUnicas.length);
        reveladas.push(letrasUnicas.splice(idx, 1)[0]);
    }
    
    return clean.split('').map(c => reveladas.includes(c) ? c : '_').join(' ');
}

function showHint() {
    if (state.hintUsed || state.gameOver) return;
    
    const hint = getHint(state.word, state.guessed, state.level);
    document.getElementById('hintText').textContent = hint;
    document.getElementById('hintSection').style.display = 'block';
    state.hintUsed = true;
    
    const btnHint = document.getElementById('btnHint');
    btnHint.disabled = true;
    btnHint.style.opacity = '0.5';
}

// ============================================================
// LÓGICA PRINCIPAL
// ============================================================
function pickWord(level) {
    const list = WORDS[level];
    return list[Math.floor(Math.random() * list.length)].toLowerCase();
}

function startGame(level) {
    if (!state.wordsLoaded) {
        alert('Cargando palabras... espera');
        return;
    }
    
    state.level = level;
    state.word = pickWord(level);
    state.guessed = new Set();
    state.wrong = 0;
    state.maxLives = LEVEL_CONFIG[level].lives;
    state.hintUsed = false;
    state.gameOver = false;
    state.correctCount = 0;
    state.wrongCount = 0;
    
    // Actualizar header
    document.getElementById('headerName').textContent = state.playerName;
    document.getElementById('headerLevel').textContent = LEVEL_CONFIG[level].name;
    
    // Construir UI
    buildKeyboard();
    buildWordDisplay(state.word, state.guessed);
    buildLives(state.maxLives);
    drawHangman(0);
    
    // Resetear contadores
    document.getElementById('wrongCount').textContent = '0';
    document.getElementById('correctCount').textContent = '0';
    document.getElementById('hintSection').style.display = 'none';
    
    const btnHint = document.getElementById('btnHint');
    btnHint.disabled = false;
    btnHint.style.opacity = '1';
    
    // Ocultar overlay
    document.getElementById('overlay').classList.remove('active');
    
    showScreen('game');
}

function handleGuess(letter) {
    if (state.gameOver) return;
    
    const upper = letter.toUpperCase();
    if (state.guessed.has(upper)) return;
    
    state.guessed.add(upper);
    
    const btn = document.querySelector(`.tecla[data-letter="${upper}"]`);
    const wordUpper = state.word.toUpperCase();
    
    if (wordUpper.includes(upper)) {
        // Acierto
        revealLetter(state.word, upper);
        if (btn) {
            btn.classList.add('correcta');
            btn.disabled = true;
        }
        state.correctCount++;
        document.getElementById('correctCount').textContent = state.correctCount;
        checkWin();
    } else {
        // Error
        state.wrong++;
        if (btn) {
            btn.classList.add('incorrecta');
            btn.disabled = true;
        }
        state.wrongCount++;
        document.getElementById('wrongCount').textContent = state.wrongCount;
        updateLives(state.wrong, state.maxLives);
        
        // Dibujar etapa del ahorcado
        const step = Math.min(Math.ceil((state.wrong / state.maxLives) * 8), 8);
        drawHangman(step);
        
        // Animación
        canvas.classList.add('shake');
        setTimeout(() => canvas.classList.remove('shake'), 300);
        
        if (state.wrong >= state.maxLives) {
            endGame(false);
        }
    }
}

function checkWin() {
    const wordUpper = state.word.toUpperCase();
    const todasLetras = [...wordUpper].every(c => state.guessed.has(c));
    if (todasLetras) endGame(true);
}

function endGame(won) {
    state.gameOver = true;
    const overlay = document.getElementById('overlay');
    const title = document.getElementById('overlayTitle');
    const wordInfo = document.getElementById('overlayWord');
    
    if (won) {
        title.textContent = '¡GANASTE!';
        title.className = 'overlay-titulo win';
        wordInfo.innerHTML = `La palabra era: ${state.word.toUpperCase()}`;
    } else {
        title.textContent = '¡PERDISTE!';
        title.className = 'overlay-titulo lose';
        wordInfo.innerHTML = `La palabra era: ${state.word.toUpperCase()}`;
        revealAll(state.word);
        drawHangman(8);
    }
    overlay.classList.add('active');
}

// ============================================================
// NAVEGACIÓN ENTRE PANTALLAS
// ============================================================
function showScreen(screenName) {
    document.querySelectorAll('.screen').forEach(s => {
        s.classList.remove('active');
    });
    document.getElementById(`screen-${screenName}`).classList.add('active');
}

// ============================================================
// INICIALIZACIÓN
// ============================================================
async function init() {
    await loadWordsFromFile();
    
    // Eventos
    document.getElementById('btnStart').onclick = () => {
        const name = document.getElementById('nameInput').value.trim();
        if (!name) {
            alert('Por favor ingresa tu nombre');
            return;
        }
        state.playerName = name;
        document.getElementById('greetName').textContent = name;
        showScreen('level');
    };
    
    document.getElementById('nameInput').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') document.getElementById('btnStart').click();
    });
    
    // Selección de nivel
    document.querySelectorAll('.nivel-card').forEach(card => {
        card.onclick = () => startGame(card.dataset.level);
    });
    
    // Botones del juego
    document.getElementById('btnHint').onclick = showHint;
    document.getElementById('btnNewWord').onclick = () => startGame(state.level);
    document.getElementById('btnChangeLevel').onclick = () => showScreen('level');
    
    // Botones del overlay
    document.getElementById('btnPlayAgain').onclick = () => startGame(state.level);
    document.getElementById('btnOverlayLevel').onclick = () => {
        document.getElementById('overlay').classList.remove('active');
        showScreen('level');
    };
    
    drawHangman(0);
}

// Arrancar el juego
init();